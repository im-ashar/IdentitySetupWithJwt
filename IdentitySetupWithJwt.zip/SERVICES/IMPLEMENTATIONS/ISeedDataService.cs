﻿
namespace $safeprojectname$.Services.Implementations
{
    public interface ISeedDataService
    {
        Task SeedDataAsync();
    }
}