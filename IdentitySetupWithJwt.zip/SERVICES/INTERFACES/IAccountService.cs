﻿using $safeprojectname$.Utilities;
using $safeprojectname$.ViewModels;

namespace $safeprojectname$.Services.Interfaces
{
    public interface IAccountService
    {
        Task<MethodResult<JwtTokenResponseVM>> LoginAsync(LoginVM loginVM);
        Task<MethodResult<JwtTokenResponseVM>> RefreshTokenAsync(string accessToken, string refreshToken);
        Task<MethodResult<RegisterVM>> RegisterAsync(RegisterVM registerVM);
    }
}